#ifndef __PART1_H__
#define __PART1_H__

void part1(char* input);

#endif
