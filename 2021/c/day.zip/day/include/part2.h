#ifndef __PART1_H__
#define __PART1_H__

void part2(char* input);

#endif
